﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioPedido
{
    public class Program
    {
        static void Main(string[] args)
        {
            int opcao = 1;

            do
            {
                Console.WriteLine("\n----------MENU----------");
                Console.WriteLine("\n1 - Cadastrar Produto");
                Console.WriteLine("\n2 - Adicionar Item");
                Console.WriteLine("\n3 - Finalizar Pedido");
                Console.WriteLine("\n\nEscolha uma opcao: ");
                opcao = int.Parse(Console.ReadLine());
                switch(opcao)
                {
                    case 1:
                        Console.WriteLine("\nDigite o valor do produto: ");
                        float preco = float.Parse(Console.ReadLine());
                        Console.WriteLine("\nDigite o nome do produto: ");
                        string nome = Console.ReadLine();
                        break;

                    case 2:
                        Console.WriteLine("\nDigite o nome do produto: ");
                        string nomeProduto = Console.ReadLine();
                        Console.WriteLine("\nDigite a quantidade do produto: ");
                        int quantidade = int.Parse(Console.ReadLine());
                        Console.WriteLine("\nDigite o disconto do produto: ");
                        float desconto = float.Parse(Console.ReadLine());
                        Item item = new Item(, quantidade, desconto, item.calcularValorItem());
                        break;
                }
                    
            }while (opcao != 0);



        }
    }
}
