﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioPedido
{
    public class Item
    {
        private Produto produto { get; set; }
        private int quantidade { get; set; }
        private float desconto { get; set; }
        private float valor { get; set; }


        public Item(Produto produto, int quantidade, float desconto, float valor)
        {
            this.produto = produto;
            this.quantidade = quantidade;
            this.desconto = desconto;
            this.valor = valor;
        }

        public float calcularValorItem()
        {
            return valor = quantidade * produto.preco;
        }

    }
}
