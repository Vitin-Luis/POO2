﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioPedido
{
    public class Pedido
    {
        private List<Item> itens { get; }
        private float valorTotal { get; set; }

        Pedido(List<Item> itens, float valorTotal)
        {
            this.itens = itens;
            this.valorTotal = valorTotal;
        }


    }
}
