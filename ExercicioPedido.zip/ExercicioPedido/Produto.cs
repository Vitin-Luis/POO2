﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExercicioPedido
{
    public class Produto
    {
        public float preco { get;}
        private string nome { get;}

        public Produto (float preco, string nome)
        {
            this.preco = preco;
            this.nome = nome;
        }


    }
}
